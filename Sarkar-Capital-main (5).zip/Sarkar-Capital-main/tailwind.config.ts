import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#f0fdf4",
          100: "#dcfce7",
          600: "#16a34a",
          800: "#166534",
          900: "#14532d",
        },
        navy: {
          800: "#0b192c",
          900: "#040d1a",
        },
      },
    },
  },
  plugins: [],
};

export default config;
